from flask import Flask, render_template, request, jsonify
from model.final_place import get_recommendations
from geopy.distance import geodesic
import pandas as pd

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/recommend", methods=["POST"])
def recommend():
    state = request.form.get("state")
    city = request.form.get("city")
    radius = float(request.form.get("travelRadius"))
    moods = request.form.getlist("vibe")
    user_lat = request.form.get("user_latitude")
    user_lon = request.form.get("user_longitude")

    print("📥 Inputs Received:", state, city, radius, moods, user_lat, user_lon)

    # Get recommendation results (list of dicts expected)
    results = get_recommendations(state, city, radius, moods)

    if not results or len(results) == 0:
        return jsonify([])

    # Convert list of dicts to DataFrame
    df = pd.DataFrame(results)
    df.columns = df.columns.str.strip()  # ✅ Remove extra spaces in column names

    # Calculate distance if coordinates are available
    if user_lat and user_lon:
        try:
            user_lat = float(user_lat)
            user_lon = float(user_lon)

            df = df[df["Latitude"].notna() & df["Longitude"].notna()]

            df["Distance (km)"] = df.apply(
                lambda row: round(
                    geodesic((user_lat, user_lon), (row["Latitude"], row["Longitude"])).km, 2
                ),
                axis=1
            )
        except Exception as e:
            print("❌ Error calculating distances:", e)
            df["Distance (km)"] = "Unknown"
    else:
        df["Distance (km)"] = "Unknown"

    # Sort by rating (or distance if needed)
    df = df.sort_values(by="Rating", ascending=False)

    print("📤 Results Returned:", df[["Place Name", "Distance (km)"]].to_dict(orient="records"))

    return jsonify(df.to_dict(orient="records"))

if __name__ == "__main__":
    app.run(debug=True)
