window.onload = function () {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (position) {
      document.getElementById("user_latitude").value = position.coords.latitude;
      document.getElementById("user_longitude").value = position.coords.longitude;
     

    }, function (error) {
      console.error("Geolocation error:", error);
    });
  } else {
    console.warn("Geolocation is not supported by this browser.");
  }
};

document.getElementById("recommendationForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const form = this;

  // Get user's current location first
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      function (position) {
        const userLat = position.coords.latitude;
        const userLon = position.coords.longitude;

        const formData = new FormData(form);
        formData.append("user_latitude", userLat);
        formData.append("user_longitude", userLon);

        fetch("/recommend", {
          method: "POST",
          body: formData
        })
          .then(response => response.json())
          .then(data => {
            const resultsDiv = document.getElementById("results");
            resultsDiv.innerHTML = "";

            if (data.length === 0) {
              resultsDiv.innerHTML = "<p>No recommendations found.</p>";
              return;
            }

            const suggestions = `
              <h2 style="color: black;">Recommended Places</h2>
              ${data.map(place => {
                const placeName = place["Place Name"] || place["place_name"] || "Unknown";
                const vibes = [
                  place["Vibe1"] || place["vibe1"],
                  place["Vibe2"] || place["vibe2"],
                  place["Vibe3"] || place["vibe3"],
                  place["Vibes"] || place["vibe"]
                ].filter(Boolean).join(", ");

                const fare = place["Entry Fee (INR)"] || place["entry_fee"] || "N/A";
                const open = place["Opening Time"] || place["opening_time"] || "N/A";
                const close = place["Closing Time"] || place["closing_time"] || "N/A";
                const distance = place["Distance (km)"] || place["distance_km"] || "Unknown";
                const lat = place["Latitude"] || place["latitude"];
                const lon = place["Longitude"] || place["longitude"];

                return `
                  <div style="
                    background: rgba(255, 255, 255, 0.08);
                    backdrop-filter: blur(10px);
                    border-radius: 15px;
                    padding: 20px;
                    margin-bottom: 15px;
                    color: black;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.3);
                  ">
                    <p style="font-size: 1.2em;"><strong>${placeName}</strong></p>
                    <p>Type: ${vibes}</p>
                    <p>Fare: ₹${fare}</p>
                    <p>Timing: ${open} - ${close}</p>
                    <p>${distance} km away from your location</p>
                    <a href="https://www.google.com/maps/search/?api=1&query=${lat},${lon}"
                      target="_blank"
                      style="display: inline-block; margin-top: 8px; background-color: #007BFF; padding: 8px 12px; color: white; text-decoration: none; border-radius: 5px;">
                      Navigate
                    </a>
                  </div>
                `;
              }).join('')}
            `;

            resultsDiv.innerHTML = suggestions;
          })
          .catch(error => {
            console.error("Error:", error);
            document.getElementById("results").innerHTML = "<p>Something went wrong. Please try again.</p>";
          });
      },
      function (error) {
        console.error("Geolocation error:", error.message);
        alert("Location permission is required to fetch recommendations.");
      }
    );
  } else {
    alert("Geolocation is not supported by your browser.");
  }
});
