import pandas as pd
import math
from model.final_place import get_all_places

def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1_rad, lon1_rad = math.radians(lat1), math.radians(lon1)
    lat2_rad, lon2_rad = math.radians(lat2), math.radians(lon2)
    dlat, dlon = lat2_rad - lat1_rad, lon2_rad - lon1_rad

    a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return round(R * c, 2)

def recommend_by_vibe(vibe_list, city=None, radius_km=None, user_lat=None, user_lon=None):
    df = get_all_places()
    df.columns = df.columns.str.strip()

    if city:
        df = df[df['City'].str.lower() == city.lower()]

    def has_any_vibe(vibe_string, target_vibes):
        place_vibes = [v.strip().lower() for v in vibe_string.split(',')]
        return any(vibe.lower() in place_vibes for vibe in target_vibes)

    filtered_df = df[df['Vibes'].apply(lambda x: has_any_vibe(x, vibe_list))]



    if user_lat is not None and user_lon is not None:
        filtered_df = filtered_df[filtered_df['Latitude'].notna() & filtered_df['Longitude'].notna()]
        filtered_df['Distance (km)'] = filtered_df.apply(
            lambda row: haversine(user_lat, user_lon, row['Latitude'], row['Longitude']),
            axis=1
        )
        if radius_km:
            filtered_df = filtered_df[filtered_df['Distance (km)'] <= radius_km]
    else:
        filtered_df['Distance (km)'] = "Unknown"

    filtered_df = filtered_df.sort_values(by=["Rating"], ascending=False).reset_index(drop=True)
    return filtered_df.to_dict(orient="records")


