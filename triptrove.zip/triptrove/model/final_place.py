import pandas as pd

# Load dataset and clean columns
df = pd.read_csv("data/Tourist_Places_India_500+_CLEANED.csv")
df.columns = df.columns.str.strip()  # ✅ Ensure column names have no extra spaces

def filter_places(city=None, vibe=None):
    filtered = df.copy()
    
    if city:
        filtered = filtered[filtered["City"].str.lower() == city.lower()]

    if vibe:
        vibe_list = [v.strip().lower() for v in vibe.split('|')]
        filtered = filtered[filtered["Vibes"].str.lower().apply(lambda x: any(v in x for v in vibe_list))]

    return filtered.sort_values(by="Rating", ascending=False)

def get_recommendations(state, city, radius, moods):
    vibe_filter = '|'.join(moods) if moods else None
    filtered = filter_places(city=city, vibe=vibe_filter)

    recommended = filtered.head(10)

    return recommended[[  # ✅ Add Latitude & Longitude if needed by frontend
        'Place Name', 'City', 'Category', 'Rating', 'Vibes',
        'Entry Fee (INR)', 'Opening Time', 'Closing Time',
        'Latitude', 'Longitude'  # ✅ Important if distance is needed later
    ]].to_dict(orient='records')
